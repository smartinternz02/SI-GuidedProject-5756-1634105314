# -*- coding: utf-8 -*-
"""
Created on Fri Jul  2 09:31:08 2021

@author: SAI
"""

print(5+6)

